// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain

// Timer
// https://youtu.be/MLtAMg9_Svw



function setup() {
  noCanvas();
  var timer = select('#timer');
 

 timer.html('0');

  function timeIt() {
    
  }

}