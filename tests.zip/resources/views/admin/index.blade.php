@extends('admin.layout.admin')
@section('content')
    <h3>Welcome To Admin Panel</h3>
@endsection