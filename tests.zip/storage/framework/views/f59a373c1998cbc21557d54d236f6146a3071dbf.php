 
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit New Score</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('score.index')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo Form::model($item, ['method' => 'PATCH','route' => ['score.update', $item->id]]); ?>

   <div class="row">
           <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                 <label class="">Team Name</label>
                 <select class="form-control" name="team">
                   <?php $__currentLoopData = $tems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($tem); ?>"><?php echo e($tem); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">Match Played</label>
                 <input type="number" name="mp" max="40" min="0" placeholder="match played" class="form-control" />
             </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">Win</label>
                 <input type="number" name="win" max="40" min="0" placeholder="win" class="form-control" />
             </div>
           </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">Draw</label>
                 <input type="number" name="draw" max="40" min="0" placeholder="draw" class="form-control" />
             </div>
           </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">loss</label>
                 <input type="number" name="loss" max="40" min="0" placeholder="loss" class="form-control" />
             </div>
           </div>
           
           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">Point</label>
                 <input type="number" name="point" max="40.00" min="0.00" placeholder="point" class="form-control" step="any" />
             </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">Tornament</label>
                 <select class="form-control" name="tournament_id">
                   <?php $__currentLoopData = $ttids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($ttid->id); ?>"><?php echo e($ttid->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
             </div>
           </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>

    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>