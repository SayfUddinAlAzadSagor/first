<?php $__env->startSection('body'); ?>
<!-- teamdetails -->
	<div class="container-fluid">
    <div class="row-fluid">
      <div class="col-md-12  profile">
          <div class="row-fluid">
            <div class="col-md-3">
              <div class="col-sm-12">
                 <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 lead"><center><a href="teams"><?php echo e($btems->name); ?></a></center><hr></div>
                        </div>
                        <div class="row">           
                            <div class="col-md-12">
                                <a href="/auction" class="w3-bar-item w3-button">Auction Teams</a><hr>
                                <a href="/batch" class="w3-bar-item w3-button">Batch Teams</a><hr>
                            </div>
                            <div class="col-md-12">
                                <form action="<?php echo e(route('teams')); ?>" method="get" class="form-inline">
                                  <div class="form-group">
                                   <input type="text" name="s" placeholder="keyword">
                                    <div class="form-group">
                                      <button class="btn-btn-success" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button> 
                                      </div>                                           
                                  </div>                                         
                                </form>
                           </div>
                      </div>
                  </div>               
                </div>
              </div>    
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12 lead"><center><h3 class="only-bottom-margin">Team Mamber</h3></center><hr>
                    </div>
                </div>
                 <?php $__empty_1 = true; $__currentLoopData = $btems->profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <div class="col-sm-4">
                     <div class="panel">
                        <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <img class="img-circle avatar avatar-original" style="-webkit-user-select:none; 
                              display:block; margin:auto;" src="<?php echo e(asset('images/'.$pro->image)); ?>">
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-4 lead"><center><small class="only-bottom-margin"><?php echo e($pro->name); ?>::</small</center></div>
                              <div class="col-md-8 lead"><center><small class="only-bottom-margin"><?php echo e($pro->position); ?></small</center></div>
                          </div>
                        </div>
                      </div>
                    </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <h2> <center>no profile</center> </h2>
                 <?php endif; ?>                        
            </div>
            <div class="col-md-3">
              <div class="row">
                    <div class="col-md-12 lead"><center><h3 class="only-bottom-margin">Manager</h3></center><hr>
                    </div>
              </div>
               <?php $__empty_1 = true; $__currentLoopData = $btems->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $man): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <div class="col-sm-12">
                     <div class="panel">
                        <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <img class="img-circle avatar avatar-original" style="-webkit-user-select:none; 
                              display:block; margin:auto;" src="<?php echo e(asset('images/'.$man->image)); ?>">
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-6 lead"><center><small class="only-bottom-margin"><?php echo e($man->name); ?>::</small</center></div>
                              <div class="col-md-6 lead"><center><small class="only-bottom-margin"> <?php echo e($man->batch); ?></small</center></div>
                          </div>
                        </div>
                      </div>
                    </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <h2> <center>no profile</center> </h2>
                 <?php endif; ?>  
            </div>
          </div>
      </div>
    </div>
    </div>
    <div class="text-right">
       
    </div> 
<!-- //teamdetails -->
		
<?php $__env->stopSection(); ?>
		
<?php echo $__env->make("layout.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>