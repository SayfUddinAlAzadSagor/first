 
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit New Schedule</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('schedule.index')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo Form::model($item, ['method' => 'PATCH','route' => ['schedule.update', $item->id]]); ?>

   <div class="row">
           <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                 <label class="">1st Team</label>
                 <select class="form-control" name="team_1">
                   <?php $__currentLoopData = $tems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($tem); ?>"><?php echo e($tem); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">2st Team</label>
                 <select class="form-control" name="team_2">
                   <?php $__currentLoopData = $tems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($tem); ?>"><?php echo e($tem); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
             </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                <strong>1st team Goal:</strong>
                <input type="number" name="goal_1" max="30" min="0" placeholder="goal" class="form-control" />
             </div>
           </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                <strong>2st team Goal:</strong>
               <input type="number" name="goal_2" max="30" min="0" placeholder="goal" class="form-control" />
             </div>
           </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>datetime:</strong>
                <input type="text" name="datetime" id="datetimepicker" class="form-control" placeholder="datetime" />
            </div>
        </div>

         <div class="col-xs-12 col-sm-12 col-md-12">
             <strong>played/not-played:</strong>
            <div class="form-group">
              <select class="form-control" name="check">
                  <option value="1">played</option>
                  <option value="0">not-played</option>
                </select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                <strong>Description:</strong>
                <?php echo Form::text('description', null, array('placeholder' => 'description','class' => 'form-control')); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">Tornament</label>
                 <select class="form-control" name="tournament_id">
                   <?php $__currentLoopData = $ttids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($ttid->id); ?>"><?php echo e($ttid->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
             </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>

    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>