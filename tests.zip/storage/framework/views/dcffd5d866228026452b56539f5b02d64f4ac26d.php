<?php $__env->startSection('body'); ?>

<!-- match -->
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="col-md-12  profile">
          <div class="row-fluid">
            <div class="col-md-3">
            <div class="col-sm-12">
               <div class="panel panel-default">
                  <div class="panel-body">
                      <div class="row">
                          <div class="col-md-12 lead"><center><a href="teams">Teams</a></center><hr></div>
                      </div>
                      <div class="row">           
                          <div class="col-md-12">
                              <a href="/auction" class="w3-bar-item w3-button">Auction Teams</a><hr>
                              <a href="/batch" class="w3-bar-item w3-button">Batch Teams</a><hr>
                          </div>
                          <div class="col-md-12">
                              <form action="<?php echo e(route('batch')); ?>" method="get" class="form-inline">
                                <div class="form-group">
                                 <input type="text" name="s" placeholder="keyword">
                                  <div class="form-group">
                                    <button class="btn-btn-success" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button> 
                                    </div>                                           
                                </div>                                         
                              </form>
                           </div>
                        </div>
                      </div>               
                    </div>
                  </div>    
              </div>
              <div class="col-sm-9">
                <div class="row">
                    <div class="col-md-12 lead"><center><h1 class="only-bottom-margin">Batch Team</h1></center><hr>
                    </div>
                </div>
                 <?php $__empty_1 = true; $__currentLoopData = $btems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $btem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-4">
                     <div class="panel panel-default">
                        <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12 lead"><h3 class="only-bottom-margin"><?php echo e($btem->name); ?></h3><hr></div>
                          </div>
                          <div class="row">
                            <div class="col-md-6 text-center">
                              <img class="img-squre avatar avatar-original" style="-webkit-user-select:none; 
                              display:block; margin:auto;" src="<?php echo e(asset('images/'.$btem->logo)); ?>">
                            </div>
                            <div class="col-md-6">
                              <div class="row">
                                <div class="col-md-12">
                                 <h4 class="only-bottom-margin">Batch:</h4>
                                 <small class="only-bottom-margin"><?php echo e($btem->batch); ?></small>
                                </div>
                              </div>
                              <h3 class="only-bottom-margin">Manager:</h3>
                              <?php if($btem->managers->count() > 0): ?>
                              <?php $__currentLoopData = $btem->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $man): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="row">
                                <div class="col-md-12">
                                  <a href="#" data-toggle="modal" data-target="#modal-<?php echo e($man->id); ?>"><small class="only-bottom-margin"><?php echo e($man->name); ?></small></a>
                                </div>
                              </div>
                               <!-- modal -->
                                    <div class="modal fade" id="modal-<?php echo e($man->id); ?>">
                                        <div class="modal-dialog modal-md">
                                            <div class="modal-content">
                                                 <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                       <h3 class="modal-title"><?php echo e($man->name); ?></h3>
                                                 </div>
                                                 <div class="modal-body">
                                                      <div class="row">
                                                        <div class="col-md-4 text-center">
                                                          <img class="img-circle avatar avatar-original" style="-webkit-user-select:none;
                                                             display:block; margin:auto;" src="<?php echo e(asset('images/'.$man->image)); ?>">
                                                        </div>
                                                        <div class="col-md-8">
                                                          <!-- <div class="row">
                                                            <div class="col-md-12">
                                                              <h3 class="only-bottom-margin">Batch Team: <?php echo e($man->name); ?></h3>
                                                              <h3 class="only-bottom-margin">Auction Team: <?php echo e($man->name); ?></h3>
                                                            </div>
                                                          </div> -->
                                                          <div class="row">
                                                            <div class="col-md-12">
                                                              <span class="text-muted">About:</span> <?php echo e($man->description); ?><br>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                 </div>
                                                 <div class="modal-footer">
                                                    <a href="" class="btn btn-default" data-dismiss="modal">Close</a>
                                                 </div>
                                            </div>
                                        </div>
                                    </div>                                
                            <!-- modalend -->
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                <small class="only-bottom-margin">manager not assign</small>
                                <?php endif; ?>
                            </div>
                          </div>
                        <div class="row">
                         <div class="col-md-12">
                           <hr><a href="batch/<?php echo e($btem->id); ?>" class="btn btn-default pull-right"><i class="fa fa-eye" aria-hidden="true"></i>View</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <h2> <center>no profile</center> </h2>
                 <?php endif; ?>                        
              </div>
           </div>
         </div>
       </div>
    </div>
    <div class="text-right">
        <?php echo e($btems->links()); ?>

    </div>
</div> 

  <?php $__env->stopSection(); ?>


  
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>