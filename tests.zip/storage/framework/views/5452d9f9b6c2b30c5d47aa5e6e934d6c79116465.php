<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Match Live</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('live.index')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo Form::open(array('route' => 'live.store','method'=>'POST')); ?>

    <div class="row">
           <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                 <label class="">1st Team Name</label>
                 <select class="form-control" name="team_1">
                   <?php $__currentLoopData = $tems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($tem->name); ?>"><?php echo e($tem->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                 <label class="">2nd Team Name</label>
                 <select class="form-control" name="team_2">
                   <?php $__currentLoopData = $tems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($tem->name); ?>"><?php echo e($tem->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">1st Team Goal</label>
                 <input type="number" name="goal_1" max="40.00" min="0.00" placeholder="goal" class="form-control" step="any" />
             </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">2nd Team Goal</label>
                 <input type="number" name="goal_2" max="40.00" min="0.00" placeholder="goal" class="form-control" step="any" />
             </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                 <label class="">1st Team Logo</label>
                 <select class="form-control" name="logo_1">
                   <?php $__currentLoopData = $tems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($tem->logo); ?>"><?php echo e($tem->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
           </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                 <label class="">2nd Team Logo</label>
                 <select class="form-control" name="logo_2">
                   <?php $__currentLoopData = $tems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($tem->logo); ?>"><?php echo e($tem->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
           </div>
           <div class="col-xs-12 col-sm-12 col-md-12">
             <div class="form-group">
                 <label class="">Time Left</label>
                  <input type="text" name="timeleft" id="datetimepicker" class="form-control" placeholder="timeleft" />
             </div>
           </div>

           <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                <strong>Url Streaming:</strong>
                <?php echo Form::text('stream', null, array('placeholder' => 'url','class' => 'form-control')); ?>

            </div>
           </div>
           
          <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description_1:</strong>
                <?php echo Form::textarea('description_1', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:100px')); ?>

            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description_2:</strong>
                <?php echo Form::textarea('description_2', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:100px')); ?>

            </div>
          </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>

    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>