<?php $__env->startSection('body'); ?>
<!-- match -->
		 <div class="container-fluid">
    <div class="row-fluid">
      <div class="col-md-12  profile">
          <div class="row-fluid">
            <div class="col-md-3">
              <div class="col-sm-12">
                 <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 lead"><center><a href="teams">Teams</a></center><hr></div>
                        </div>
                        <div class="row">           
                            <div class="col-md-12">
                                <a href="/auction" class="w3-bar-item w3-button">Auction Teams</a><hr>
                                <a href="/batch" class="w3-bar-item w3-button">Batch Teams</a><hr>
                            </div>
                            <div class="col-md-12">
                                <form action="<?php echo e(route('teams')); ?>" method="get" class="form-inline">
                                  <div class="form-group">
                                   <input type="text" name="s" placeholder="keyword">
                                    <div class="form-group">
                                      <button class="btn-btn-success" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button> 
                                      </div>                                           
                                  </div>                                         
                                </form>
                           </div>
                      </div>
                  </div>               
                </div>
              </div>    
            </div>
             <div class="col-sm-9">
                <div class="row">
                    <div class="col-md-12 lead"><center><h1 class="only-bottom-margin">Auction Team</h1></center><hr>
                    </div>
                </div>
                 <?php $__empty_1 = true; $__currentLoopData = $atems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                 <a style="display:block" href="auction/<?php echo e($atem->id); ?>">
                    <div class="col-sm-4">
                     <div class="panel panel-default">
                        <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12 lead"><h3 class="only-bottom-margin"><?php echo e($atem->name); ?></h3><hr></div>
                          </div>
                          <small class="text-muted"><center>Created at: <?php echo e($atem->created_at->format('d-m-Y')); ?></center></small>
                        </div>
                      </div>
                    </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <h2> <center>no profile</center> </h2>
                 <?php endif; ?>                        
                <div class="row">
                    <div class="col-md-12 lead"><center><h1 class="only-bottom-margin">Batch Team</h1></center><hr>
                    </div>
                </div>
                 <?php $__empty_1 = true; $__currentLoopData = $btems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $btem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <a style="display:block" href="batch/<?php echo e($btem->id); ?>">
                    <div class="col-sm-4">
                     <div class="panel panel-default">
                        <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12 lead"><h3 class="only-bottom-margin"><?php echo e($btem->name); ?></h3><hr></div>
                          </div>
                          <small class="text-muted"><center>Batch : <?php echo e($btem->batch); ?></center></small>
                        </div>
                      </div>
                    </div>
                   </a> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <h2> <center>no profile</center> </h2>
                 <?php endif; ?>                        
              </div>

           </div>
        </div>
    </div>
    </div>
    <div class="text-right">
        <?php echo e($atems->links()); ?>

    </div>
</div> 
		<!-- //match -->
		
<?php $__env->stopSection(); ?>
		
<?php echo $__env->make("layout.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>