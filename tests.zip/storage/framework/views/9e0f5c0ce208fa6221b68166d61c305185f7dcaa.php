<?php $__env->startSection('body'); ?>



 <div class="container-fluid">
    <div class="row-fluid">
       <div class="col-md-12  profile">
          <div class="row-fluid">

              <div class="col-md-3">
                  <div class="col-sm-12">
                     <div class="panel panel-default">
                        <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12 lead"><center><a href="/tournament">Tournaments</a></center><hr></div>
                          </div>
                          <div class="row">
                              <?php $__empty_1 = true; $__currentLoopData = $trmts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-12">
                                      <a href="/tournament/<?php echo e($trmt->id); ?>" class="w3-bar-item w3-button"><?php echo e($trmt->name); ?></a><hr>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <h2> <center>no tornament avaible</center> </h2>
                              <?php endif; ?>
                                <div class="col-md-12">
                                      <form action="<?php echo e(route('tournament')); ?>" method="get" class="form-inline">
                                        <div class="form-group">
                                            <input type="text" name="s" placeholder="keyword">
                                            <div class="form-group">
                                               <button class="btn-btn-success" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button> 
                                            </div>                                           
                                        </div>                                      
                                      </form>
                                </div>  
                           </div>
                        </div>
                      </div>
                   </div>
              </div>
              <?php if($ids != null): ?>
              <div class="col-sm-9">
                <div class="row">
                  <div class="col-md-12 lead"><h1 class="only-bottom-margin"><center><?php echo e($ids->name); ?></center></h1><hr></div>
                </div>
                <div class="col-md-12">
                  <div class="col-sm-7">
                    <div class="panel">
                      <div class="panel-body">
                         <div class="col-sm-12"><center>Schedule</center></div><hr>
                         <table class="table table-striped">
                          <thead>
                            <tr>
                              <th scope="col">No</th>
                              <th scope="col">Date And Time</th>
                              <th scope="col">Team</th>
                              <th scope="col">Results</th>
                              <th scope="col">view</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ids->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                            <th scope="row"><?php echo e(++$i); ?></th>                            
                              <td><?php echo e($id->datetime); ?></td>
                              <td><?php echo e($id->team_1); ?> vs <?php echo e($id->team_2); ?></td>
                              <?php if($id->check == 1): ?>
                              <td><?php echo e($id->goal_1); ?>-<?php echo e($id->goal_2); ?></td>
                              <?php else: ?>
                              <td>not yet played</td>
                               <td class="fa fa-eye" aria-hidden="true"></td>
                              <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <?php endif; ?>
                            
                          </tbody>
                        </table>
                          
                      </div>
                    </div>
                  </div>
                   <?php $i=0; ?>
                  <div class="col-sm-5">
                    <div class="panel">
                      <div class="panel-body">  
                        <div class="col-sm-12"><center>Points Table</center></div><hr>
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th scope="col">No</th>
                              <th scope="col">Team</th>
                              <th scope="col">MP</th>
                              <th scope="col">W</th>
                              <th scope="col">D</th>
                              <th scope="col">L</th>
                              <th scope="col">Pts</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ids->scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                            <th scope="row"><?php echo e(++$i); ?></th>                            
                              <td><?php echo e($id->team); ?></td>
                              <td><?php echo e($id->mp); ?></td>
                               <td><?php echo e($id->win); ?></td>
                              <td><?php echo e($id->draw); ?></td>
                               <td><?php echo e($id->loss); ?></td>
                              <td><?php echo e($id->point); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <?php endif; ?>
                            
                          </tbody>
                        </table>
                        <div class="row">
                           <div class="col-md-12 lead"><center><br><br><br><h5 class="only-bottom-margin">About Tournament</h5></center><hr>
                           </div>
                           <div><h6><center><?php echo e($trmt->description); ?></center></h6></div>
                       </div>
                      </div>
                    </div>
                  </div>
                </div>                     
              </div>
              <?php endif; ?>
              
           </div>
        </div>
    </div>
    <div class="text-right">
        <?php echo e($trmts->appends(['s' => $s])->links()); ?>

    </div>
</div> 


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>