<?php $__env->startSection('body'); ?>
<!-- gallery -->
		<div class="gallery">
			<!-- Page Starts Here -->
			<div class="content">
				<div class="container">
					<div class="gallery">
						<h3>Photo Gallery</h3>
						<div class="gallery-top">
							
							<?php $__empty_1 = true; $__currentLoopData = $galls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<div class="view view-tenth">
								<img src="<?php echo e(asset('gallery/'.$gall->photo)); ?>" />
								<div class="mask">
									<h2><?php echo e($gall->title); ?></h2>
									<p><?php echo e($gall->description); ?></p>
									<a href="#" class="info">Read More</a>
								</div>
							</div>
							 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h2> <center>no Gallery</center> </h2>
                           <?php endif; ?>
							
							<div class="clearfix"></div>
						</div>
					</div>
					<?php echo e($galls->links()); ?>

				</div>

			</div>
			<!-- Page Ends Here -->
		</div>
		<!-- //gallery -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>