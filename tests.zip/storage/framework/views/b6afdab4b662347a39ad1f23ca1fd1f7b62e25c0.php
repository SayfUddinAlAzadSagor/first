<div class="col-md-3"> 
  <div class="col-sm-12">
     <div class="panel panel-default">
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12 lead"><center><a href="teams">Teams</a></center><hr></div>
            </div>
            <div class="row">           
                <div class="col-md-12">
                    <a href="/teams/auction" class="w3-bar-item w3-button">Auction Teams</a><hr>
                    <a href="/teams/batch" class="w3-bar-item w3-button">Batch Teams</a><hr>
                </div>
                <div class="col-md-12">
                    <form action="<?php echo e(route('teams')); ?>" method="get" class="form-inline">
                      <div class="form-group">
                       <input type="text" name="s" placeholder="keyword">
                        <div class="form-group">
                          <button class="btn-btn-success" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button> 
                          </div>                                           
                      </div>                                         
                    </form>
               </div>
          </div>
      </div>               
    </div>
  </div>    
</div>