 
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Player Profile</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('profile.create')); ?>"> Create New Team</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Reg no</th>
            <th>Rating</th>
            <th>Jarsey no</th>
            <th>Batch</th>
            <th>Image</th>
            <th>Position</th>
            <th>Description</th>
             <th>Batch Team </th>
            <th>Auction Team </th>
            <th width="280px">Action</th>
        </tr>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->registration_no); ?></td>
        <td><?php echo e($item->rating); ?></td>
        <td><?php echo e($item->jarsey_no); ?></td>
        <td><?php echo e($item->batch); ?></td>
        <td><?php echo e($item->image); ?></td>
        <td><?php echo e($item->position); ?></td>
        <td><?php echo e($item->description); ?></td>
        <td><?php echo e($item->batchteam->name); ?></td>
        <td><?php echo e($item->auctionteam->name); ?></td>
        <td>
            <a class="btn btn-info" href="<?php echo e(route('profile.show',$item->id)); ?>">Show</a>
            <a class="btn btn-primary" href="<?php echo e(route('profile.edit',$item->id)); ?>">Edit</a>
            <?php echo Form::open(['method' => 'DELETE','route' => ['profile.destroy', $item->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $items->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>