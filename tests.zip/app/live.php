<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class live extends Model
{
     public $fillable = ['team_1','team_2','goal_1','goal_2','logo_1','logo_2','timeleft','stream','description_1','description_2'];

  
}
